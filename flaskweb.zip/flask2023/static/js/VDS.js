// JavaScript for the Website

document.addEventListener('DOMContentLoaded', function() {
    // Image Slider
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide-container');

    function showSlide(index) {
        slides.forEach((slide) => slide.classList.remove('active'));
        slides[index].classList.add('active');
    }

    function next() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    function prev() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
    }

    document.getElementById('next').addEventListener('click', next);
    document.getElementById('prev').addEventListener('click', prev);

    // Mobile Menu Toggle
    const menuBar = document.getElementById('menu-bar');
    const navBar = document.querySelector('.navbar');

    menuBar.addEventListener('click', function() {
        navBar.classList.toggle('active');
    });



    // Form Validation
    const form = document.getElementById('contact-form');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        if (name.trim() === '' || email.trim() === '' || message.trim() === '') {
            alert('Please fill in all fields');
        } else if (!isValidEmail(email)) {
            alert('Please enter a valid email address');
        } else {
            alert('Form submitted successfully');
            // You can add code here to handle the form submission, e.g., send data to a server.
        }
    });

    function isValidEmail(email) {
        // Simple email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Smooth Scrolling
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);

            window.scrollTo({
                top: targetElement.offsetTop - 100, // Adjust for fixed header
                behavior: 'smooth'
            });
        });
    });
    const addToCartButtons = document.querySelectorAll('.add-to-cart');

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.product;

            // Check if the product is already in the cart
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            const existingProduct = cart.find(item => item.id === productId);

            if (existingProduct) {
                existingProduct.quantity++;
            } else {
                cart.push({ id: productId, quantity: 1 });
            }

            localStorage.setItem('cart', JSON.stringify(cart));

            alert('Product added to cart!');
        });
    });
});
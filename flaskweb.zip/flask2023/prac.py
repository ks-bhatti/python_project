from flask import Flask, render_template, request, redirect, session,flash
from flask_sqlalchemy import SQLAlchemy
import bcrypt

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///prac.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# Initialize the app with the extension
db = SQLAlchemy(app)
app.secret_key = 'secret_key'

# Database
class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String(100), nullable=False)
    product_price = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=False)
    password = db.Column(db.String(100))

    def __init__(self, email, password, name):
        self.name = name
        self.email = email

        # Hash the password before storing it in the database9
        self.password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        

    # Check the password
    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password.encode('utf-8'))  
 # Add the relationship
    cart_items = db.relationship('CartItem', backref='user', lazy=True)
with app.app_context():
    db.create_all()

# Home route
@app.route("/")
def home():
    return render_template('Website.html')
@app.route("/user")
def user():
    return render_template('user.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            
            session['name'] = user.name
            session['email'] = user.email
            return redirect('/user')
        else:
            return "Invalid login credentials"

    return render_template('login.html')

# Sign-up route
@app.route('/sign-up', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

    #check email
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already exists. Please choose a different email.", 'error')
            return redirect('/sign-up')
        
        new_user = User(email=email, password=password, name=name)
        db.session.add(new_user)
        db.session.commit()
        return redirect('/login')

    return render_template('signup.html')


#logout 
@app.route('/logout')
def logout():
    session.clear()
    return render_template('website.html')


@app.route('/cart')
def cart():
    if 'email' in session:
        user = User.query.filter_by(email=session['email']).first()
        cart_items = user.cart_items
        return render_template('cart.html', cart_items=cart_items)
    else:
        return render_template('login.html')
    
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'email' in session:
        user = User.query.filter_by(email=session['email']).first()
        
        product_name = request.form['product_name']
        product_price = float(request.form['product_price'])

        new_cart_item = CartItem(product_name=product_name, product_price=product_price, user=user)
        db.session.add(new_cart_item)
        db.session.commit()

        flash('Item added to the cart successfully', 'success')
        return redirect('/cart')
    else:
        return redirect('/login')
   
     

if __name__ == "__main__":
    app.run(debug=True)
